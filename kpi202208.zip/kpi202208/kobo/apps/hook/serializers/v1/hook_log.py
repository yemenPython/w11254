# coding: utf-8
from kobo.apps.hook.serializers.v2.hook_log import \
    HookLogSerializer as HookLogSerializerV2


class HookLogSerializer(HookLogSerializerV2):

    pass
