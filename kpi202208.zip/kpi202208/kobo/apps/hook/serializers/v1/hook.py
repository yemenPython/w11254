# coding: utf-8
from kobo.apps.hook.serializers.v2.hook import HookSerializer as HookSerializerV2


class HookSerializer(HookSerializerV2):

    pass
