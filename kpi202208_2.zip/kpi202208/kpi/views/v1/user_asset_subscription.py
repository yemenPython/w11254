# coding: utf-8
from kpi.views.v2.user_asset_subscription import (
    UserAssetSubscriptionViewSet as UserAssetSubscriptionViewSetV2,
)


class UserAssetSubscriptionViewSet(UserAssetSubscriptionViewSetV2):
    pass
