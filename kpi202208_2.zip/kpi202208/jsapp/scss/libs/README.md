This directory is for scss versions of libraries that need to be modified in
this project. They are primarily imported from 'main.scss'.

For best results, commit the unedited stylesheet before making changes, so that
deviations can be viewed.
